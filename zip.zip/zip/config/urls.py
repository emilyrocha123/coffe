from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views  # Importação necessária para as views de autenticação
from app.views import (
    IndexView,
    ProdutoCreateView,
    CategoriaCreateView,
    AvaliacaoCreateView,
    CarrinhoView,
    FinalizarCompraView,
    custom_login_view,
    register_view,
    AdicionarAoCarrinhoView,  # Importando a view para adicionar ao carrinho
    RemoverDoCarrinhoView,  # Importando a view para remover item do carrinho
    AumentarQuantidadeView,  # Importando a view para aumentar a quantidade
    DiminuirQuantidadeView,  # Importando a view para diminuir a quantidade
    BuscarProdutosView,  # Importando a view de busca de produtos
    CompraSucessoView, 
    ProdutoDetailView # Importando a view de sucesso da compra
)

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls, name='admin'),  # Painel administrativo
    path('', IndexView.as_view(), name='index'),  # Página inicial
    path('login/', custom_login_view, name='login'),  # View de login personalizada
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),  # Logout padrão
    path('register/', register_view, name='register'),  # Página de registro
    path('produto/novo/', ProdutoCreateView.as_view(), name='produto_create'),  # Adicionar produto
    path('carrinho/', CarrinhoView.as_view(), name='carrinho'),  # Ver carrinho
    path('carrinho/adicionar/', AdicionarAoCarrinhoView.as_view(), name='adicionar_ao_carrinho'),  # Adicionar item ao carrinho
    path('finalizar-compra/', FinalizarCompraView.as_view(), name='finalizar_compra'),  # Finalizar compra
    path('carrinho/remover/<int:produto_id>/', RemoverDoCarrinhoView.as_view(), name='remover_do_carrinho'),
    path('carrinho/aumentar/<int:produto_id>/', AumentarQuantidadeView.as_view(), name='aumentar_quantidade'),
    path('carrinho/diminuir/<int:produto_id>/', DiminuirQuantidadeView.as_view(), name='diminuir_quantidade'),
    path('categorias/', CategoriaCreateView.as_view(), name='categoria_list'),
    path('avaliacao/criar/', AvaliacaoCreateView.as_view(), name='avaliacao_criar'),
    path('buscar/', BuscarProdutosView.as_view(), name='buscar_produtos'),  # URL de busca de produtos
    path('compra-sucedida/', CompraSucessoView.as_view(), name='compra_sucesso'),  
    path('produto/<int:pk>/', ProdutoDetailView.as_view(), name='detalhes_produto'),# URL da página de sucesso
    path('produto/<int:produto_id>/avaliar/', AvaliacaoCreateView.as_view(), name='avaliar_produto'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)  # Configuração para servir arquivos de mídia
