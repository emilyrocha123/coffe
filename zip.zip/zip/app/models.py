from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError


class Categoria(models.Model):
    nome = models.CharField(max_length=100, verbose_name="Nome da categoria")

    def __str__(self):
        return self.nome

    class Meta:
        verbose_name = "Categoria"
        verbose_name_plural = "Categorias"


class Produto(models.Model):
    nome = models.CharField(max_length=100, verbose_name="Nome do produto")
    descricao = models.TextField(verbose_name="Descrição do produto")
    preco = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Preço")
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE, verbose_name="Categoria")
    disponivel = models.BooleanField(default=True, verbose_name="Disponível")
    imagem = models.ImageField(upload_to='produtos/', blank=True, null=True, verbose_name="Imagem do produto")

    def __str__(self):
        return self.nome

      

    class Meta:
        verbose_name = "Produto"
        verbose_name_plural = "Produtos"





class Carrinho(models.Model):
    usuario = models.CharField(max_length=100, verbose_name="Usuário")
    data_criacao = models.DateTimeField(auto_now_add=True, verbose_name="Data de criação")

    def __str__(self):
        return f"Carrinho de {self.usuario}"

    class Meta:
        verbose_name = "Carrinho"
        verbose_name_plural = "Carrinhos"


class ItemCarrinho(models.Model):
    carrinho = models.ForeignKey(Carrinho, on_delete=models.CASCADE, verbose_name="Carrinho")
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE, verbose_name="Produto")
    quantidade = models.PositiveIntegerField(default=1, verbose_name="Quantidade")

    def __str__(self):
        return f"{self.quantidade} x {self.produto.nome} no carrinho"

    class Meta:
        verbose_name = "Item do Carrinho"
        verbose_name_plural = "Itens do Carrinho"


class Endereco(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name="Usuário")
    cep = models.CharField(max_length=10, verbose_name="CEP")
    rua = models.CharField(max_length=255, verbose_name="Rua")
    numero = models.CharField(max_length=10, verbose_name="Número")
    cidade = models.CharField(max_length=100, verbose_name="Cidade")
    estado = models.CharField(max_length=50, verbose_name="Estado")

    def clean(self):
        """
        Valida o CEP para garantir que tenha exatamente 8 dígitos numéricos.
        """
        # Remove caracteres não numéricos do CEP
        cep_num = ''.join(filter(str.isdigit, self.cep))
        if len(cep_num) != 8:
            raise ValidationError('O CEP deve ter exatamente 8 dígitos.')
        self.cep = cep_num  # Garante que o CEP seja armazenado apenas com números

    def save(self, *args, **kwargs):
        self.clean()  # Chama a validação personalizada antes de salvar
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.rua}, {self.numero} - {self.cidade}/{self.estado}"

    class Meta:
        verbose_name = "Endereço"
        verbose_name_plural = "Endereços"

class Avaliacao(models.Model):
    usuario = models.ForeignKey(User, related_name='avaliacoes', on_delete=models.CASCADE)
    produto = models.ForeignKey(Produto, related_name='avaliacoes', on_delete=models.CASCADE)
    nota = models.PositiveIntegerField(choices=[(i, i) for i in range(1, 6)])  # Notas de 1 a 5
    comentario = models.TextField(null=True, blank=True)
    data_criacao = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Avaliação de {self.usuario.username} para {self.produto.nome}"

    class Meta:
        unique_together = ('usuario', 'produto')  #