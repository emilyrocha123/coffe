from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic import DetailView
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.urls import reverse
from io import BytesIO
from reportlab.pdfgen import canvas
from .models import Produto, Endereco, Avaliacao
from .forms import ProdutoForm

class FinalizarCompraView(View):
    def get(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.warning(request, 'Você precisa estar logado para finalizar a compra.')
            return redirect('login')

        # Recupera o carrinho da sessão
        carrinho = request.session.get('carrinho', {})
        if not carrinho:
            messages.warning(request, 'Seu carrinho está vazio.')
            return redirect('carrinho')

        # Calcula o total da compra
        total_compra = sum(float(item['preco']) * item['quantidade'] for item in carrinho.values())

        # Recupera o endereço do usuário logado
        endereco = Endereco.objects.filter(user=request.user).first()

        # Passa o carrinho, o total e o endereço para o template
        return render(request, 'finalizar_compra.html', {
            'carrinho': carrinho,
            'total_compra': total_compra,
            'endereco': endereco
        })

    def post(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.warning(request, 'Você precisa estar logado para finalizar a compra.')
            return redirect('login')

        carrinho = request.session.get('carrinho', {})
        if not carrinho:
            messages.warning(request, 'Seu carrinho está vazio.')
            return redirect('carrinho')

        total_compra = sum(float(item['preco']) * item['quantidade'] for item in carrinho.values())

        forma_pagamento = request.POST.get('forma_pagamento')

        if forma_pagamento == 'boleto':
            return self.gerar_boleto(request, total_compra)

        if total_compra > 0:
            # Lógica para processar pagamento aqui (não implementado)
            messages.success(request, f'Compra finalizada com sucesso! Total: R${total_compra:.2f}')
            request.session['carrinho'] = {}  # Limpa o carrinho após a compra
            return redirect('index')

        messages.error(request, 'Erro ao processar pagamento.')
        return redirect('finalizar_compra')

    def gerar_boleto(self, request, total_compra):
        # Gerar boleto (simulação simples com reportlab)
        buffer = BytesIO()
        p = canvas.Canvas(buffer)
        p.drawString(100, 800, f"Seu Boleto - Total: R$ {total_compra:.2f}")
        p.drawString(100, 780, f"Beneficiário: Seu Waldir Cafés Especiais")
        p.drawString(100, 760, f"Vencimento: 10/12/2024")
        p.drawString(100, 740, f"Total a pagar: R$ {total_compra:.2f}")
        p.showPage()
        p.save()

        buffer.seek(0)
        response = HttpResponse(buffer, content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="boleto.pdf"'
        return response

class IndexView(View):
    def get(self, request, *args, **kwargs):
        produtos = Produto.objects.filter(disponivel=True)
        return render(request, 'index.html', {'produtos': produtos})


class ProdutoCreateView(View):
    def get(self, request, *args, **kwargs):
        form = ProdutoForm()
        return render(request, 'produtoforms.html', {'form': form})

    def post(self, request, *args, **kwargs):
        form = ProdutoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Produto criado com sucesso.')
            return redirect('produto_list')  # Ajuste o nome da URL de listagem
        messages.error(request, 'Erro ao criar produto. Verifique os dados fornecidos.')
        return render(request, 'produtoforms.html', {'form': form})


class CategoriaCreateView(View):
    def get(self, request, *args, **kwargs):
        # Recupera os produtos disponíveis
        produtos = Produto.objects.all()

        # Renderiza o template passando os produtos
        return render(request, 'categoria_form.html', {'produtos': produtos})

    def post(self, request, *args, **kwargs):
        # Implementar lógica de criação de categoria
        pass

class AvaliacaoCreateView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'avaliacao_form.html')

    def post(self, request, *args, **kwargs):
        # Implementar lógica de criação de avaliação
        pass


class CarrinhoView(View):
    def get(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.warning(request, 'Você precisa estar logado para acessar o carrinho.')
            return redirect('login')

        carrinho = request.session.get('carrinho', {})

        for produto_id, item in carrinho.items():
            item['subtotal'] = float(item['preco']) * item['quantidade']

        total_geral = sum(item['subtotal'] for item in carrinho.values())
        return render(request, 'carrinho.html', {'carrinho': carrinho, 'total_geral': total_geral})

class FinalizarCompraView(View):
    def get(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.warning(request, 'Você precisa estar logado para finalizar a compra.')
            return redirect('login')

        # Recupera o carrinho da sessão
        carrinho = request.session.get('carrinho', {})
        if not carrinho:
            messages.warning(request, 'Seu carrinho está vazio.')
            return redirect('carrinho')

        # Calcula o total da compra
        total_compra = sum(float(item['preco']) * item['quantidade'] for item in carrinho.values())

        # Recupera o endereço do usuário logado
        endereco = Endereco.objects.filter(user=request.user).first()

        # Passa o carrinho, o total e o endereço para o template
        return render(request, 'finalizar_compra.html', {
            'carrinho': carrinho,
            'total_compra': total_compra,
            'endereco': endereco
        })

    def post(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.warning(request, 'Você precisa estar logado para finalizar a compra.')
            return redirect('login')

        carrinho = request.session.get('carrinho', {})
        if not carrinho:
            messages.warning(request, 'Seu carrinho está vazio.')
            return redirect('carrinho')

        total_compra = sum(float(item['preco']) * item['quantidade'] for item in carrinho.values())

        if total_compra > 0:
            # Lógica para processar pagamento aqui (não implementado)
            messages.success(request, f'Compra finalizada com sucesso! Total: R${total_compra:.2f}')
            request.session['carrinho'] = {}  # Limpa o carrinho após a compra
            return redirect('index')

        messages.error(request, 'Erro ao processar pagamento.')
        return redirect('finalizar_compra')
    
    def post(self, request, *args, **kwargs):
        # Lógica para finalizar a compra
        # Após finalizar a compra, redirecionar para a página de sucesso
        return redirect('compra_sucesso')



class AdicionarAoCarrinhoView(View):
    def post(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.warning(request, 'Você precisa estar logado para adicionar produtos ao carrinho.')
            return redirect('login')

        produto_id = request.POST.get('produto_id')
        quantidade = int(request.POST.get('quantidade', 1))

        try:
            produto = Produto.objects.get(id=produto_id)
        except Produto.DoesNotExist:
            messages.error(request, 'Produto não encontrado.')
            return redirect('index')

        carrinho = request.session.get('carrinho', {})
        if produto_id in carrinho:
            carrinho[produto_id]['quantidade'] += quantidade
        else:
            carrinho[produto_id] = {
                'nome': produto.nome,
                'preco': str(produto.preco),
                'quantidade': quantidade
            }

        request.session['carrinho'] = carrinho
        messages.success(request, f'{produto.nome} foi adicionado ao seu carrinho.')
        return redirect('carrinho')




def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        cep = request.POST.get('cep')
        rua = request.POST.get('rua')
        numero = request.POST.get('numero')
        cidade = request.POST.get('cidade')
        estado = request.POST.get('estado')

        if User.objects.filter(username=username).exists():
            messages.error(request, 'Esse nome de usuário já existe.')
            return render(request, 'register.html', {'username': username})

        user = User.objects.create_user(username=username, password=password, email=email)
        Endereco.objects.create(user=user, cep=cep, rua=rua, numero=numero, cidade=cidade, estado=estado)
        login(request, user)
        messages.success(request, 'Cadastro realizado com sucesso!')
        return redirect('index')

    username = request.GET.get('username', '')
    return render(request, 'register.html', {'username': username})


def custom_login_view(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            messages.error(request, 'Usuário não encontrado. Você pode se cadastrar.')
            return redirect(reverse('register') + f'?email={email}')

        user = authenticate(request, username=user.username, password=password)
        if user:
            login(request, user)
            messages.success(request, 'Login realizado com sucesso!')
            return redirect('index')

        messages.error(request, 'Credenciais inválidas.')
        return render(request, 'login.html')

    return render(request, 'login.html')

class AumentarQuantidadeView(View):
    def post(self, request, produto_id, *args, **kwargs):
        # Recuperar o carrinho da sessão
        carrinho = request.session.get('carrinho', {})

        if str(produto_id) in carrinho:  # Verificar se o produto está no carrinho
            carrinho[str(produto_id)]['quantidade'] += 1  # Aumenta a quantidade
            # Atualiza o subtotal do produto
            carrinho[str(produto_id)]['subtotal'] = float(carrinho[str(produto_id)]['preco']) * carrinho[str(produto_id)]['quantidade']

        request.session['carrinho'] = carrinho  # Atualiza a sessão com o novo carrinho
        return redirect('carrinho')


class DiminuirQuantidadeView(View):
    def post(self, request, produto_id, *args, **kwargs):
        # Recuperar o carrinho da sessão
        carrinho = request.session.get('carrinho', {})

        if str(produto_id) in carrinho and carrinho[str(produto_id)]['quantidade'] > 1:  # Só diminui se a quantidade for maior que 1
            carrinho[str(produto_id)]['quantidade'] -= 1  # Diminui a quantidade
            # Atualiza o subtotal do produto
            carrinho[str(produto_id)]['subtotal'] = float(carrinho[str(produto_id)]['preco']) * carrinho[str(produto_id)]['quantidade']

        request.session['carrinho'] = carrinho  # Atualiza a sessão com o novo carrinho
        return redirect('carrinho')

class RemoverDoCarrinhoView(View):
    def post(self, request, produto_id, *args, **kwargs):  # Alterando de GET para POST
        carrinho = request.session.get('carrinho', {})

        # Verificar se o produto existe no carrinho
        if str(produto_id) in carrinho:
            # Remover o item
            del carrinho[str(produto_id)]
            request.session['carrinho'] = carrinho
            messages.success(request, 'Produto removido do carrinho com sucesso.')
        else:
            messages.error(request, 'Produto não encontrado no carrinho.')

        return redirect('carrinho')

class BuscarProdutosView(View):
    template_name = 'categoria_form.html'  # Substitua pelo nome do seu template
    context_object_name = 'produtos'  # O nome que os produtos terão no contexto

    def get(self, request, *args, **kwargs):
        query = self.request.GET.get('q', '')
        
        if query:
            # Filtra os produtos com base no nome (case-insensitive) e só produtos disponíveis
            produtos = Produto.objects.filter(nome__icontains=query, disponivel=True)
        else:
            # Retorna todos os produtos disponíveis
            produtos = Produto.objects.filter(disponivel=True)

        return render(request, self.template_name, {self.context_object_name: produtos, 'query': query})
    
class CompraSucessoView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'compra_sucesso.html')  
    

class ProdutoDetailView(DetailView):
    model = Produto
    template_name = 'detalhes_produto.html'
    context_object_name = 'produto'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['avaliacoes'] = Avaliacao.objects.filter(produto=self.object)
        return context

class AvaliacaoCreateView(View):
    def get(self, request, produto_id, *args, **kwargs):
        produto = Produto.objects.get(id=produto_id)
        return render(request, 'avaliacao_form.html', {'produto': produto})

    def post(self, request, produto_id, *args, **kwargs):
        produto = Produto.objects.get(id=produto_id)
        nota = request.POST.get('nota')
        comentario = request.POST.get('comentario')

        if not nota or not comentario:
            messages.error(request, 'Nota e comentário são obrigatórios!')
            return redirect('avaliacao_create', produto_id=produto_id)

        # Cria a avaliação
        avaliacao = Avaliacao.objects.create(
            usuario=request.user,
            produto=produto,
            nota=nota,
            comentario=comentario
        )

        messages.success(request, 'Avaliação realizada com sucesso!')
        return redirect('produto_detail', pk=produto.id)
