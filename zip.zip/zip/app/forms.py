from django import forms
from .models import Produto, Categoria, Avaliacao

class ProdutoForm(forms.ModelForm):
    class Meta:
        model = Produto
        fields = ['nome', 'descricao', 'preco', 'categoria', 'disponivel']

class CategoriaForm(forms.ModelForm):
    class Meta:
        model = Categoria
        fields = ['nome']

class AvaliacaoForm(forms.ModelForm):
    """Formulário para criação de avaliações"""
    nota = forms.IntegerField(
        min_value=1,
        max_value=5,
        required=True,
        label="Nota",
        help_text="Dê uma nota de 1 a 5."
    )
    comentario = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 5}),
        required=False,
        label="Comentário",
        help_text="Escreva um comentário (opcional)."
    )

    class Meta:
        model = Avaliacao
        fields = ['nota', 'comentario']

    def clean_comentario(self):
        comentario = self.cleaned_data.get('comentario', '')
        if len(comentario) > 500:
            raise forms.ValidationError("O comentário não pode exceder 500 caracteres.")
        return comentario