from django.contrib import admin
from .models import Categoria, Produto, Avaliacao, Carrinho, ItemCarrinho, Endereco

@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ('nome', 'id')  # Exibir o nome e o ID da categoria
    search_fields = ('nome',)  # Permitir buscar pela categoria pelo nome
    list_per_page = 20  # Limitar a exibição a 20 categorias por página

@admin.register(Produto)
class ProdutoAdmin(admin.ModelAdmin):
    list_display = ('nome', 'preco', 'disponivel', 'categoria')
    list_filter = ('disponivel', 'categoria')
    search_fields = ('nome', 'descricao')

@admin.register(Avaliacao)
class AvaliacaoAdmin(admin.ModelAdmin):
    list_display = ('produto', 'usuario', 'nota', 'data_criacao')
    list_filter = ('nota', 'data_criacao')
    search_fields = ('usuario', 'comentario')

@admin.register(Carrinho)
class CarrinhoAdmin(admin.ModelAdmin):
    list_display = ('usuario', 'data_criacao')

@admin.register(ItemCarrinho)
class ItemCarrinhoAdmin(admin.ModelAdmin):
    list_display = ('carrinho', 'produto', 'quantidade')

@admin.register(Endereco)
class EnderecoAdmin(admin.ModelAdmin):
    list_display = ('user', 'cep', 'cidade', 'estado')
    search_fields = ('user__username', 'cep', 'cidade', 'estado')
class AvaliacaoAdmin(admin.ModelAdmin):
    list_display = ('usuario', 'produto', 'get_nota', 'comentario', 'data_criacao')

    def get_nota(self, obj):
        # Converte o rating em uma string amigável
        return f"{obj.rating} estrela{'s' if obj.rating > 1 else ''}"
    get_nota.short_description = 'Nota'

