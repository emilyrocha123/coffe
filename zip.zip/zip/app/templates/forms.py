from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.models import Endereco


class UserForm(forms.ModelForm):
    """Formulário para os dados do usuário"""
    username = forms.CharField(max_length=150, required=True)
    email = forms.EmailField(required=True)
    password = forms.CharField(widget=forms.PasswordInput, required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

class EnderecoForm(forms.ModelForm):
    """Formulário para os dados do endereço"""
    cep = forms.CharField(max_length=10, required=True)
    rua = forms.CharField(max_length=255, required=True)
    numero = forms.CharField(max_length=10, required=True)
    cidade = forms.CharField(max_length=100, required=True)
    estado = forms.CharField(max_length=50, required=True)

    class Meta:
        model = Endereco
        fields = ['cep', 'rua', 'numero', 'cidade', 'estado']

    def clean_cep(self):
        cep = self.cleaned_data.get('cep')
        # Remove caracteres não numéricos
        cep_num = ''.join(filter(str.isdigit, cep))
        if len(cep_num) != 8:
            raise forms.ValidationError('O CEP deve ter exatamente 8 dígitos.')
        return cep


class RegisterForm(forms.Form):
    """Formulário combinado para registro de usuário e endereço"""
    user_form = UserForm()
    endereco_form = EnderecoForm()

    def save(self):
        # Salvar o usuário
        user = self.cleaned_data['user_form'].save()

        # Salvar o endereço
        endereco = self.cleaned_data['endereco_form']
        endereco.user = user
        endereco.save()

        return user  # Retorna o usuário para login automático ou outra ação
